import React, { useState, useEffect } from "react";
import FormularioTarea from "./FormularioTarea";
import { v4 as uuid } from "uuid";
import './estilos.css'; 

// Componente principal para listar las tareas
export default function ListaTareas() {
    const [tareas, setTareas] = useState([]); // Estado para almacenar las tareas
    const [expandida, setExpandida] = useState(null); // Estado para controlar qué nota está expandida

    // Hook para cargar las tareas desde localStorage al iniciar el componente
    useEffect(() => {
        const misTareas = JSON.parse(localStorage.getItem("tareas-app"));
        if (misTareas) {
            setTareas(misTareas);
        }
    }, []);

    // Hook para guardar las tareas en localStorage cada vez que cambian
    useEffect(() => {
        const json = JSON.stringify(tareas);
        localStorage.setItem("tareas-app", json);
    }, [tareas]);

    // Función para agregar una nueva tarea al estado
    const agregarTarea = (titulo, tarea, importante) => {
        const nuevaTarea = { id: uuid(), titulo: titulo, tarea: tarea, importante: importante };
        setTareas((prev) => [...prev, nuevaTarea]);
    }

    // Función para alternar el estado expandido de una nota
    const toggleExpandida = (id) => {
        setExpandida(expandida === id ? null : id);
    }

    return (
        <div>
            <h2>Listado de tareas</h2>
            {/* Componente del formulario para agregar nuevas tareas */}
            <FormularioTarea onAgregarTarea={agregarTarea} />
            <div className="note-container">
                {/* Mapeo de las tareas para mostrarlas como notas */}
                {tareas.map((t) => (
                    <div 
                        key={t.id} 
                        className={`note ${t.importante ? 'important' : ''} ${expandida === t.id ? 'expanded' : ''}`}
                        onClick={() => toggleExpandida(t.id)}
                    >
                        <h3>{t.titulo}</h3>
                        <p>{t.tarea}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}
