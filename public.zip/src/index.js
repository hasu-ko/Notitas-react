import React from 'react';
import ReactDOM from 'react-dom/client';
import ListaTareas from './ListaTareas';

/**
 * Archivo principal de entrada de la aplicación.
 * Renderiza el componente principal ListaTareas en el elemento con id 'root'.
 */
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <div className='container pt-3'>
        <ListaTareas></ListaTareas>
    </div>
);
