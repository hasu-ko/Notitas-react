import React, { useRef, useState } from 'react';

export default function FormularioTarea({ onAgregarTarea }) {
    const tituloRef = useRef();
    const tareaRef = useRef();
    const [importante, setImportante] = useState(false);

    // Maneja la adición de una nueva tarea
    const handleAgregar = () => {
        const titulo = tituloRef.current.value.trim();
        const tarea = tareaRef.current.value.trim();
        if (titulo === "" || tarea === "") {
            alert("Por favor, ingrese un título y una tarea válidos.");
            return;
        }
        onAgregarTarea(titulo, tarea, importante);
        tituloRef.current.value = ""; // Limpiar el input del título después de agregar
        tareaRef.current.value = ""; // Limpiar el input de la tarea después de agregar
        setImportante(false); // Resetear el estado de importancia
    }

    return (
        <div className="form-inline">
            <input ref={tituloRef} className="form-control" placeholder="título"></input>
            <input ref={tareaRef} className="form-control" placeholder="Descripcion"></input>
            <div className="form-check">
                <input 
                    className="form-check-input" 
                    type="checkbox" 
                    id="importanteCheckbox" 
                    checked={importante} 
                    onChange={() => setImportante(!importante)} 
                />
                <label className="form-check-label" htmlFor="importanteCheckbox">
                    Importante!
                </label>
            </div>
            <button onClick={handleAgregar} className="btn btn-primary btn-primary-custom">Agregar</button>
        </div>
    );
}
