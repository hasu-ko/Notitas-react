import React from "react";

export default function ItemTarea(props) {

    return (
        <li className="list-group-item">{props.tarea}</li>
        
    )
}